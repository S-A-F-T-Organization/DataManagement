"""Main module execution for saft_data_mgmt package."""
from saft_data_mgmt.setup_saft_db import main

if __name__ == "__main__":
    main()
