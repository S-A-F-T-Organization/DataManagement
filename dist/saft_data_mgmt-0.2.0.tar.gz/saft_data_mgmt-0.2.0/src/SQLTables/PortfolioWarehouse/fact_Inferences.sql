CREATE OR ALTER TABLE fact_Inferences (
    inference_key INTEGER NOT NULL,
    inference_date_key INTEGER NOT NULL,
)
