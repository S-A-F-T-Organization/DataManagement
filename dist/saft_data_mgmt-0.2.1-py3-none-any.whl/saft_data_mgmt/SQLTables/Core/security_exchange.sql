CREATE TABLE IF NOT EXISTS SecurityExchanges (
    [exchange_id] INTEGER PRIMARY KEY,
    [exchange] TEXT NOT NULL,
    UNIQUE(Exchange)
)